package assignment;
import java.util.*;
public class shape {
	int a,l,b;double d,pi=3.14;
	shape(){
		 System .out.println(" default ");
	}
	shape(int a1){
		a=a1;
	}
	shape(int l1,int b1){
		l=l1;b=b1;
	}
	shape(double d1){
		d=d1;
	}
	public double square() {
		return d*d;
	}
	public int rectangle() {
		return l*b;
	}
	public int circle() {
		return (int)(pi*a*a);
	}
	public int area(int m,int n) {
		return (m*n)/2;
	}
	public int area(double x,int y) {
		return (int)((x*y)/2);
	}
	public static void main(String args[]) {
		shape s=new shape();
		shape s1=new shape(6);
		shape s2=new shape(5,6);
		shape s3=new shape(10);
		System.out.println("area of the circle    :"+s3.circle());
		System.out.println("area of the rectangle :"+s2.rectangle());
		System.out.println("area of the square    :"+s1.square());
		System.out.println("area of the rhombus   :"+s.area(5,6));
		System.out.println("area of the triangle   :"+s.area(5.8,6));
	}

}



package assignment;
import java.util.*;
public class phase2 {
	double pi=3.14;
	public int calculate(int a,int b) {
		return a+b;
	}
	public int calculate(int c) {
		return (int) (pi*c*c);
	}
	public int calculate(double l,double h) {
		return (int)(l*h);
	}
	public int calculate(double  s) {
		return (int)(s*s);
	}
	public static void main(String args[]) {
		phase2 c=new phase2();
		System.out.println("add two numbers       :"+c.calculate(5,6));
		System.out.println("area of the circle    :"+c.calculate(5));
		System.out.println("area of the rectangle :"+c.calculate(10,8.6));
		System.out.println("area of the square    :"+c.calculate(5.6));
		
}
}